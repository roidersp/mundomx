var w=$(window).width();
var h=$(window).height();


console.log("w:"+w);
console.log("w-:"+ ((2500-w)/2));

var w2=((2500-w));
var varX=(w/2);
var vleft=(2500-w)/2;
var pointX=0;
 var pointY=0;
console.log(-((2500-w)/2)+"px 0px");


var f=2500-w;
 $("#indepth_imag_cont").css('background-position',-f+"px 0px");


var b=(2500-w)/2;
var a=(1250)-(w/2);



$("#indepth_imag_cont").mousemove(function(event){
	

	
	pointX=((varX-event.pageX)*100)/((2500-w)/2);
	
	
	pointX=(w2/2)-event.pageX;
	
	console.log(event.pageX);
	
	$("#indepth_imag_cont").css('background-position',(pointX)+"px 0px");
	
	//console.log(pointX);
	/*if(pointX>1135){
		$("#indepth_mundo").css('transform', "translate("+1135+"px,0px)");
	}else{
		$("#indepth_mundo").css('transform', "translate("+(pointX)+"px,0px)");
	}*/
	
	//console.log(event.pageX+"-"+event.pageY);
	
	//$(this).css('background-position', center center;)
});

